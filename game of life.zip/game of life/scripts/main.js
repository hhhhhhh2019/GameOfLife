var game = new Game(320, 320, 'black', 40, 40);

var hod = document.createElement('input');
document.body.appendChild(hod);

var colR = document.createElement('input');
document.body.appendChild(colR);

var hodd = 1;

var a = 0;

var over = false;

var foods = game.foods;

var rects = game.rects;

var maxFood = 1000;

var maxRect = 300;

var xf, yf = 0;
var xr, yr = 0;

xf = Math.round(Math.random()*14);
yf = Math.round(Math.random()*14);

foods.push(new game.food({
            x : xf, y : yf,
            c : 'yellow'
}))


xr = Math.round(Math.random()*14);
yr = Math.round(Math.random()*14);

rects.push(new game.rect({
                     x : xr, y : yr,
                     c : 'blue',
                     energy : 100,
                     pok : 1,
                     team : 0,
                     command : [57,57,57,57,57,57,57,
                                57,57,57,57,57,57,57,
                                57,57,57,57,57,57,57,
                                57,57,57,57,57,57,57,
                                57,57,57,57,57,57,57,
                                57,57,57,57,57,57,57,
                                57,57,57,57,57,57,57,
                                57,57,57,57,57,57,57,
                                57,57,57,57,57,57,57,57]
          }))

game.update = function (){
   //create food
   if (foods.length <= 0){
      xf = Math.round(Math.random()*14);
      yf = Math.round(Math.random()*14);
      foods.push(new game.food({
         x : xf, y : yf,
         c : 'yellow'
      }))
   }
   if (foods.length > 0){
   if (rects.length > 0){
   if (foods.length < maxFood){
      for (var i = 0; i < 1; i++){
         xf = Math.round(Math.random()*14);
         yf = Math.round(Math.random()*14);
         if (foods[i].x == xf && foods[i].y == yf){
            xf = Math.round(Math.random()*14);
            yf = Math.round(Math.random()*14);
         }
         if (rects[i].x == xf && rects[i].y == yf){
            xf = Math.round(Math.random()*14);
            yf = Math.round(Math.random()*14);
         }
         foods.push(new game.food({
            x : xf, y : yf,
            c : 'yellow'
         }))
      }
   }
   }
   //draw food
   for (var i = 0; i < foods.length; i++){
       foods[i].draw();
   }
   }
   
   //draw rect
   //if(a > 50){
      for (var i = 0; i < rects.length; i++){
          rects[i].nextCmd();
          rects[i].draw();
          if (rects[i].energy < 0)
             rects.splice(i, 1);
      }
     
   //}
   
   for (var i = 0; i < rects.length; i++){
       for (var u = 0; u < foods.length; u++){
           if (rects[i].y == foods[u].y && rects[i].x == foods[u].x){
              foods.splice(u, 1);
              rects[i].energy += 10;
              rects[i].eatF++;
           }
       }
   }
   for (var i = 0; i < rects.length; i++){
      for (var u = 0; u < rects.length; u++){
          if (!i == u){
             if (rects[i].y == rects[u].y && rects[i].x == rects[u].x){
                rects[i].energy += rects[u].energy;
                rects[i].kill++;
                rects.splice(u, 1);
             }
          }
      }
   }
   for (var i = 0; i < rects.length; i++){
       if (rects[i].energy >= 100){
          rects.push(new game.rect({
                     x : rects[i].x-1, y : rects[i].y-1,
                     c : 'blue',
                     energy : 95,
                     pok : rects[i].pok+1,
                     command : rects[i].command
          }))
          rects.push(new game.rect({
                     x : rects[i].x+1, y : rects[i].y+1,
                     c : 'blue',
                     energy : 95,
                     pok : rects[i].pok+1,
                     command : rects[i].command
          }))
          rects.push(new game.rect({
                     x : rects[i].x+1, y : rects[i].y-1,
                     c : 'blue',
                     energy : 95,
                     pok : rects[i].pok+1,
                     command : rects[i].command
          }))
          rects[i].command[Math.round(Math.random()*rects[i].command.length)]=Math.round(Math.random()*64);
      }
   }
   if (rects.length == 0){
     if (!over){
      game.msg(2, "game over");
      over = true;
     }
   }
   if (rects.length > maxRect){
      rects.splice(1, Math.round(rects.length/4));
   }
   //game.msg(1, rects.length);
   //a++;
   if (!over){
      hod.value = Math.round(hodd) + " days";
      hodd+=0.3;
   }
   
   /*/for (var i = 0; i < rects.length; i++){
       for (var u = 0;u < rects.length; u++){
           if (rects[i].x+1 == rects[u].x){
       }
   }*/
   
   colR.value = rects.length + " rects";
   
   game.pause(0);
}
game.Start();