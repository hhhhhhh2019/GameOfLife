function Game(W, H, C, RW, RH){
   'use strict'
   //variables
   var D = document;
   var _this = this;
   var cnv = D.createElement('canvas');
   var ctx = cnv.getContext('2d');
   cnv.style.width = W + "px";
   cnv.style.height = H + "px";
   cnv.style.backgroundColor = C;
   
   this.msg = function(t, s){
      if (t == 1){
         console.log(s);
      }
      if (t == 2){
         alert(s);
      }
   }
   
   this.pause = function (ms){
       var d = new Date();
       var c, diff;
       while (1) {
       c=new Date();
       diff = c-d;
       if (diff > ms) break;
       }
   }
   
   this.update = function(){
      _this.msg(1, "update't defined");
   }
   
   this.engine = function(){
      requestAnimationFrame(_this.engine);
      ctx.fillStyle = C;
      ctx.fillRect(0, 0, W, H);
      _this.update();
   }
   
   this.Start = function(){
      D.body.appendChild(cnv);
      _this.engine();
   }
   
   this.drawRect = function (x, y, w, h, c){
      ctx.fillStyle = c;
      ctx.fillRect(x, y, w, h);
   }
   
   //foods
   this.foods = [];
   
   this.food = function (param){
      this.x = param.x*2*10;this.y = param.y*10;
      this.w = 10*2; this.h = 10;
      this.c = param.c;
   }
   //foods functions
   this.food.prototype = {
      draw : function (){
         _this.drawRect(this.x, this.y, this.w, this.h, this.c);
      }
   }
   
   //rects
   this.rects = [];
   this.rect = function (param){
      this.x = param.x*2*10;this.y = param.y*10;
      this.w = 10*2; this.h = 10;
      this.energy = param.energy;
      this.c = param.c;
      this.command = param.command;
      this.cmd = 0;
      this.d = 1;
      this.ph = 0;
      this.kill = 0;
      this.eatF = 0;
      this.pok = param.pok;
      this.team = param.team;
   }
   //rects functions
   this.rect.prototype = {
      draw : function (){
         _this.drawRect(this.x, this.y, this.w, this.h, this.c);
      },
      nextCmd : function (){
         if (this.command[this.cmd] >= 1 && this.command[this.cmd] <= 20) {
            this.cmd++;
            if (this.command[this.cmd] >= 9 && this.command[this.cmd] <= 16) this.d = this.command[this.cmd]-8;
            else if (this.command[this.cmd] >= 17 && this.command[this.cmd] <= 24) this.d = this.command[this.cmd]-16;
            else if (this.command[this.cmd] >= 25 && this.command[this.cmd] <= 32) this.d = this.command[this.cmd]-24;
            else if (this.command[this.cmd] >= 33 && this.command[this.cmd] <= 43) this.d = this.command[this.cmd]-32;
            else if (this.command[this.cmd] >= 44 && this.command[this.cmd] <= 52) this.d = this.command[this.cmd]-40;
            else this.d = this.command[this.cmd];
            this.cmd += this.d;
            if (this.cmd > this.command.length) this.cmd = 0;
         }
         if (this.command[this.cmd] >= 21 && this.command[this.cmd] <= 54){
            this.move();
         }
         if (this.command[this.cmd] >= 55 && this.command[this.cmd] <= 64){
            this.energy += 1;
            this.ph+=2;
         }
         if (this.command[this.cmd] == 0){
         }
         this.cmd++;
         if (this.cmd-1 > this.command.length) this.cmd = 0;
         this.energy-=1;
         if (this.ph-10 > this.kill+this.eatF) this.c = 'green'
         if (this.kill > this.ph-(this.eatF)/1.5) this.c = 'red'
         if (this.eatF > this.ph-this.kill) this.c = 'blue'
      },
      move : function (){
         if (this.d == 1){this.y-=10}
         if (this.d == 2){this.y-=10;this.x+=10*2}
         if (this.d == 3){this.x+=10*2}
         if (this.d == 4){this.y+=10;this.x+=10*2}
         if (this.d == 5){this.y+=10}
         if (this.d == 6){this.y+=10;this.x-=10*2}
         if (this.d == 7){this.x-=10*2}
         if (this.d == 8){this.y-=10;this.x-=10*2}
         if (this.y < 0)this.y = 10*2*10-60;
         if (this.x < 0)this.x = 10*10*2+80;
         if (this.x >= 10*2*10+100)this.x = 0;
         if (this.y >= 10*10*2-50)this.y = 0;
      }
   }
   
}